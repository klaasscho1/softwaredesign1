/**
 */
package RootElement.ClassDiagrams;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see RootElement.ClassDiagrams.ClassDiagramsFactory
 * @model kind="package"
 * @generated
 */
public interface ClassDiagramsPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "ClassDiagrams";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http:///RootElement/ClassDiagrams.ecore";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "RootElement.ClassDiagrams";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	ClassDiagramsPackage eINSTANCE = RootElement.ClassDiagrams.impl.ClassDiagramsPackageImpl.init();

	/**
	 * The meta object id for the '{@link RootElement.ClassDiagrams.impl.EnvironmentImpl <em>Environment</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.ClassDiagrams.impl.EnvironmentImpl
	 * @see RootElement.ClassDiagrams.impl.ClassDiagramsPackageImpl#getEnvironment()
	 * @generated
	 */
	int ENVIRONMENT = 0;

	/**
	 * The number of structural features of the '<em>Environment</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENVIRONMENT_FEATURE_COUNT = 0;

	/**
	 * The operation id for the '<em>Environment</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENVIRONMENT___ENVIRONMENT = 0;

	/**
	 * The number of operations of the '<em>Environment</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENVIRONMENT_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link RootElement.ClassDiagrams.impl.MainImpl <em>Main</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.ClassDiagrams.impl.MainImpl
	 * @see RootElement.ClassDiagrams.impl.ClassDiagramsPackageImpl#getMain()
	 * @generated
	 */
	int MAIN = 1;

	/**
	 * The number of structural features of the '<em>Main</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAIN_FEATURE_COUNT = 0;

	/**
	 * The operation id for the '<em>Main</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAIN___MAIN = 0;

	/**
	 * The number of operations of the '<em>Main</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAIN_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link RootElement.ClassDiagrams.impl.Robot_PickerImpl <em>Robot Picker</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.ClassDiagrams.impl.Robot_PickerImpl
	 * @see RootElement.ClassDiagrams.impl.ClassDiagramsPackageImpl#getRobot_Picker()
	 * @generated
	 */
	int ROBOT_PICKER = 2;

	/**
	 * The feature id for the '<em><b>Velocity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROBOT_PICKER__VELOCITY = 0;

	/**
	 * The feature id for the '<em><b>No Of Cherries</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROBOT_PICKER__NO_OF_CHERRIES = 1;

	/**
	 * The number of structural features of the '<em>Robot Picker</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROBOT_PICKER_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Robot Picker</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROBOT_PICKER_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link RootElement.ClassDiagrams.impl.RobotImpl <em>Robot</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.ClassDiagrams.impl.RobotImpl
	 * @see RootElement.ClassDiagrams.impl.ClassDiagramsPackageImpl#getRobot()
	 * @generated
	 */
	int ROBOT = 3;

	/**
	 * The feature id for the '<em><b>Velocity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROBOT__VELOCITY = 0;

	/**
	 * The feature id for the '<em><b>Rotation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROBOT__ROTATION = 1;

	/**
	 * The feature id for the '<em><b>Tore Time</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROBOT__TORE_TIME = 2;

	/**
	 * The number of structural features of the '<em>Robot</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROBOT_FEATURE_COUNT = 3;

	/**
	 * The operation id for the '<em>Robot</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROBOT___ROBOT = 0;

	/**
	 * The operation id for the '<em>Init Behavior</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROBOT___INIT_BEHAVIOR = 1;

	/**
	 * The operation id for the '<em>Perform Behavior</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROBOT___PERFORM_BEHAVIOR = 2;

	/**
	 * The number of operations of the '<em>Robot</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROBOT_OPERATION_COUNT = 3;

	/**
	 * The meta object id for the '{@link RootElement.ClassDiagrams.impl.Robot_BumperImpl <em>Robot Bumper</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.ClassDiagrams.impl.Robot_BumperImpl
	 * @see RootElement.ClassDiagrams.impl.ClassDiagramsPackageImpl#getRobot_Bumper()
	 * @generated
	 */
	int ROBOT_BUMPER = 4;

	/**
	 * The feature id for the '<em><b>Velocity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROBOT_BUMPER__VELOCITY = 0;

	/**
	 * The feature id for the '<em><b>Rotation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROBOT_BUMPER__ROTATION = 1;

	/**
	 * The number of structural features of the '<em>Robot Bumper</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROBOT_BUMPER_FEATURE_COUNT = 2;

	/**
	 * The operation id for the '<em>Robot Bumper</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROBOT_BUMPER___ROBOT_BUMPER = 0;

	/**
	 * The operation id for the '<em>Init Behavior</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROBOT_BUMPER___INIT_BEHAVIOR = 1;

	/**
	 * The operation id for the '<em>Bump</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROBOT_BUMPER___BUMP = 2;

	/**
	 * The operation id for the '<em>Perform Behavior</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROBOT_BUMPER___PERFORM_BEHAVIOR = 3;

	/**
	 * The number of operations of the '<em>Robot Bumper</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROBOT_BUMPER_OPERATION_COUNT = 4;

	/**
	 * The meta object id for the '{@link RootElement.ClassDiagrams.impl.Robot_CameraImpl <em>Robot Camera</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RootElement.ClassDiagrams.impl.Robot_CameraImpl
	 * @see RootElement.ClassDiagrams.impl.ClassDiagramsPackageImpl#getRobot_Camera()
	 * @generated
	 */
	int ROBOT_CAMERA = 5;

	/**
	 * The feature id for the '<em><b>Velocity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROBOT_CAMERA__VELOCITY = 0;

	/**
	 * The feature id for the '<em><b>Rotation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROBOT_CAMERA__ROTATION = 1;

	/**
	 * The feature id for the '<em><b>Camera</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROBOT_CAMERA__CAMERA = 2;

	/**
	 * The number of structural features of the '<em>Robot Camera</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROBOT_CAMERA_FEATURE_COUNT = 3;

	/**
	 * The operation id for the '<em>Init Behavior</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROBOT_CAMERA___INIT_BEHAVIOR = 0;

	/**
	 * The operation id for the '<em>Perform Behavior</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROBOT_CAMERA___PERFORM_BEHAVIOR = 1;

	/**
	 * The operation id for the '<em>Robot Camera</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROBOT_CAMERA___ROBOT_CAMERA = 2;

	/**
	 * The number of operations of the '<em>Robot Camera</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROBOT_CAMERA_OPERATION_COUNT = 3;


	/**
	 * Returns the meta object for class '{@link RootElement.ClassDiagrams.Environment <em>Environment</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Environment</em>'.
	 * @see RootElement.ClassDiagrams.Environment
	 * @generated
	 */
	EClass getEnvironment();

	/**
	 * Returns the meta object for the '{@link RootElement.ClassDiagrams.Environment#Environment() <em>Environment</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Environment</em>' operation.
	 * @see RootElement.ClassDiagrams.Environment#Environment()
	 * @generated
	 */
	EOperation getEnvironment__Environment();

	/**
	 * Returns the meta object for class '{@link RootElement.ClassDiagrams.Main <em>Main</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Main</em>'.
	 * @see RootElement.ClassDiagrams.Main
	 * @generated
	 */
	EClass getMain();

	/**
	 * Returns the meta object for the '{@link RootElement.ClassDiagrams.Main#Main() <em>Main</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Main</em>' operation.
	 * @see RootElement.ClassDiagrams.Main#Main()
	 * @generated
	 */
	EOperation getMain__Main();

	/**
	 * Returns the meta object for class '{@link RootElement.ClassDiagrams.Robot_Picker <em>Robot Picker</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Robot Picker</em>'.
	 * @see RootElement.ClassDiagrams.Robot_Picker
	 * @generated
	 */
	EClass getRobot_Picker();

	/**
	 * Returns the meta object for the attribute '{@link RootElement.ClassDiagrams.Robot_Picker#getVelocity <em>Velocity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Velocity</em>'.
	 * @see RootElement.ClassDiagrams.Robot_Picker#getVelocity()
	 * @see #getRobot_Picker()
	 * @generated
	 */
	EAttribute getRobot_Picker_Velocity();

	/**
	 * Returns the meta object for the attribute '{@link RootElement.ClassDiagrams.Robot_Picker#getNoOfCherries <em>No Of Cherries</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>No Of Cherries</em>'.
	 * @see RootElement.ClassDiagrams.Robot_Picker#getNoOfCherries()
	 * @see #getRobot_Picker()
	 * @generated
	 */
	EAttribute getRobot_Picker_NoOfCherries();

	/**
	 * Returns the meta object for class '{@link RootElement.ClassDiagrams.Robot <em>Robot</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Robot</em>'.
	 * @see RootElement.ClassDiagrams.Robot
	 * @generated
	 */
	EClass getRobot();

	/**
	 * Returns the meta object for the attribute '{@link RootElement.ClassDiagrams.Robot#getVelocity <em>Velocity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Velocity</em>'.
	 * @see RootElement.ClassDiagrams.Robot#getVelocity()
	 * @see #getRobot()
	 * @generated
	 */
	EAttribute getRobot_Velocity();

	/**
	 * Returns the meta object for the attribute '{@link RootElement.ClassDiagrams.Robot#getRotation <em>Rotation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Rotation</em>'.
	 * @see RootElement.ClassDiagrams.Robot#getRotation()
	 * @see #getRobot()
	 * @generated
	 */
	EAttribute getRobot_Rotation();

	/**
	 * Returns the meta object for the attribute '{@link RootElement.ClassDiagrams.Robot#getToreTime <em>Tore Time</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Tore Time</em>'.
	 * @see RootElement.ClassDiagrams.Robot#getToreTime()
	 * @see #getRobot()
	 * @generated
	 */
	EAttribute getRobot_ToreTime();

	/**
	 * Returns the meta object for the '{@link RootElement.ClassDiagrams.Robot#Robot() <em>Robot</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Robot</em>' operation.
	 * @see RootElement.ClassDiagrams.Robot#Robot()
	 * @generated
	 */
	EOperation getRobot__Robot();

	/**
	 * Returns the meta object for the '{@link RootElement.ClassDiagrams.Robot#initBehavior() <em>Init Behavior</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Init Behavior</em>' operation.
	 * @see RootElement.ClassDiagrams.Robot#initBehavior()
	 * @generated
	 */
	EOperation getRobot__InitBehavior();

	/**
	 * Returns the meta object for the '{@link RootElement.ClassDiagrams.Robot#performBehavior() <em>Perform Behavior</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Perform Behavior</em>' operation.
	 * @see RootElement.ClassDiagrams.Robot#performBehavior()
	 * @generated
	 */
	EOperation getRobot__PerformBehavior();

	/**
	 * Returns the meta object for class '{@link RootElement.ClassDiagrams.Robot_Bumper <em>Robot Bumper</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Robot Bumper</em>'.
	 * @see RootElement.ClassDiagrams.Robot_Bumper
	 * @generated
	 */
	EClass getRobot_Bumper();

	/**
	 * Returns the meta object for the attribute '{@link RootElement.ClassDiagrams.Robot_Bumper#getVelocity <em>Velocity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Velocity</em>'.
	 * @see RootElement.ClassDiagrams.Robot_Bumper#getVelocity()
	 * @see #getRobot_Bumper()
	 * @generated
	 */
	EAttribute getRobot_Bumper_Velocity();

	/**
	 * Returns the meta object for the attribute '{@link RootElement.ClassDiagrams.Robot_Bumper#getRotation <em>Rotation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Rotation</em>'.
	 * @see RootElement.ClassDiagrams.Robot_Bumper#getRotation()
	 * @see #getRobot_Bumper()
	 * @generated
	 */
	EAttribute getRobot_Bumper_Rotation();

	/**
	 * Returns the meta object for the '{@link RootElement.ClassDiagrams.Robot_Bumper#Robot_Bumper() <em>Robot Bumper</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Robot Bumper</em>' operation.
	 * @see RootElement.ClassDiagrams.Robot_Bumper#Robot_Bumper()
	 * @generated
	 */
	EOperation getRobot_Bumper__Robot_Bumper();

	/**
	 * Returns the meta object for the '{@link RootElement.ClassDiagrams.Robot_Bumper#initBehavior() <em>Init Behavior</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Init Behavior</em>' operation.
	 * @see RootElement.ClassDiagrams.Robot_Bumper#initBehavior()
	 * @generated
	 */
	EOperation getRobot_Bumper__InitBehavior();

	/**
	 * Returns the meta object for the '{@link RootElement.ClassDiagrams.Robot_Bumper#bump() <em>Bump</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Bump</em>' operation.
	 * @see RootElement.ClassDiagrams.Robot_Bumper#bump()
	 * @generated
	 */
	EOperation getRobot_Bumper__Bump();

	/**
	 * Returns the meta object for the '{@link RootElement.ClassDiagrams.Robot_Bumper#performBehavior() <em>Perform Behavior</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Perform Behavior</em>' operation.
	 * @see RootElement.ClassDiagrams.Robot_Bumper#performBehavior()
	 * @generated
	 */
	EOperation getRobot_Bumper__PerformBehavior();

	/**
	 * Returns the meta object for class '{@link RootElement.ClassDiagrams.Robot_Camera <em>Robot Camera</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Robot Camera</em>'.
	 * @see RootElement.ClassDiagrams.Robot_Camera
	 * @generated
	 */
	EClass getRobot_Camera();

	/**
	 * Returns the meta object for the attribute '{@link RootElement.ClassDiagrams.Robot_Camera#getVelocity <em>Velocity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Velocity</em>'.
	 * @see RootElement.ClassDiagrams.Robot_Camera#getVelocity()
	 * @see #getRobot_Camera()
	 * @generated
	 */
	EAttribute getRobot_Camera_Velocity();

	/**
	 * Returns the meta object for the attribute '{@link RootElement.ClassDiagrams.Robot_Camera#getRotation <em>Rotation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Rotation</em>'.
	 * @see RootElement.ClassDiagrams.Robot_Camera#getRotation()
	 * @see #getRobot_Camera()
	 * @generated
	 */
	EAttribute getRobot_Camera_Rotation();

	/**
	 * Returns the meta object for the attribute list '{@link RootElement.ClassDiagrams.Robot_Camera#getCamera <em>Camera</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Camera</em>'.
	 * @see RootElement.ClassDiagrams.Robot_Camera#getCamera()
	 * @see #getRobot_Camera()
	 * @generated
	 */
	EAttribute getRobot_Camera_Camera();

	/**
	 * Returns the meta object for the '{@link RootElement.ClassDiagrams.Robot_Camera#initBehavior() <em>Init Behavior</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Init Behavior</em>' operation.
	 * @see RootElement.ClassDiagrams.Robot_Camera#initBehavior()
	 * @generated
	 */
	EOperation getRobot_Camera__InitBehavior();

	/**
	 * Returns the meta object for the '{@link RootElement.ClassDiagrams.Robot_Camera#performBehavior() <em>Perform Behavior</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Perform Behavior</em>' operation.
	 * @see RootElement.ClassDiagrams.Robot_Camera#performBehavior()
	 * @generated
	 */
	EOperation getRobot_Camera__PerformBehavior();

	/**
	 * Returns the meta object for the '{@link RootElement.ClassDiagrams.Robot_Camera#Robot_Camera() <em>Robot Camera</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Robot Camera</em>' operation.
	 * @see RootElement.ClassDiagrams.Robot_Camera#Robot_Camera()
	 * @generated
	 */
	EOperation getRobot_Camera__Robot_Camera();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	ClassDiagramsFactory getClassDiagramsFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link RootElement.ClassDiagrams.impl.EnvironmentImpl <em>Environment</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.ClassDiagrams.impl.EnvironmentImpl
		 * @see RootElement.ClassDiagrams.impl.ClassDiagramsPackageImpl#getEnvironment()
		 * @generated
		 */
		EClass ENVIRONMENT = eINSTANCE.getEnvironment();

		/**
		 * The meta object literal for the '<em><b>Environment</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ENVIRONMENT___ENVIRONMENT = eINSTANCE.getEnvironment__Environment();

		/**
		 * The meta object literal for the '{@link RootElement.ClassDiagrams.impl.MainImpl <em>Main</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.ClassDiagrams.impl.MainImpl
		 * @see RootElement.ClassDiagrams.impl.ClassDiagramsPackageImpl#getMain()
		 * @generated
		 */
		EClass MAIN = eINSTANCE.getMain();

		/**
		 * The meta object literal for the '<em><b>Main</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation MAIN___MAIN = eINSTANCE.getMain__Main();

		/**
		 * The meta object literal for the '{@link RootElement.ClassDiagrams.impl.Robot_PickerImpl <em>Robot Picker</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.ClassDiagrams.impl.Robot_PickerImpl
		 * @see RootElement.ClassDiagrams.impl.ClassDiagramsPackageImpl#getRobot_Picker()
		 * @generated
		 */
		EClass ROBOT_PICKER = eINSTANCE.getRobot_Picker();

		/**
		 * The meta object literal for the '<em><b>Velocity</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ROBOT_PICKER__VELOCITY = eINSTANCE.getRobot_Picker_Velocity();

		/**
		 * The meta object literal for the '<em><b>No Of Cherries</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ROBOT_PICKER__NO_OF_CHERRIES = eINSTANCE.getRobot_Picker_NoOfCherries();

		/**
		 * The meta object literal for the '{@link RootElement.ClassDiagrams.impl.RobotImpl <em>Robot</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.ClassDiagrams.impl.RobotImpl
		 * @see RootElement.ClassDiagrams.impl.ClassDiagramsPackageImpl#getRobot()
		 * @generated
		 */
		EClass ROBOT = eINSTANCE.getRobot();

		/**
		 * The meta object literal for the '<em><b>Velocity</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ROBOT__VELOCITY = eINSTANCE.getRobot_Velocity();

		/**
		 * The meta object literal for the '<em><b>Rotation</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ROBOT__ROTATION = eINSTANCE.getRobot_Rotation();

		/**
		 * The meta object literal for the '<em><b>Tore Time</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ROBOT__TORE_TIME = eINSTANCE.getRobot_ToreTime();

		/**
		 * The meta object literal for the '<em><b>Robot</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ROBOT___ROBOT = eINSTANCE.getRobot__Robot();

		/**
		 * The meta object literal for the '<em><b>Init Behavior</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ROBOT___INIT_BEHAVIOR = eINSTANCE.getRobot__InitBehavior();

		/**
		 * The meta object literal for the '<em><b>Perform Behavior</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ROBOT___PERFORM_BEHAVIOR = eINSTANCE.getRobot__PerformBehavior();

		/**
		 * The meta object literal for the '{@link RootElement.ClassDiagrams.impl.Robot_BumperImpl <em>Robot Bumper</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.ClassDiagrams.impl.Robot_BumperImpl
		 * @see RootElement.ClassDiagrams.impl.ClassDiagramsPackageImpl#getRobot_Bumper()
		 * @generated
		 */
		EClass ROBOT_BUMPER = eINSTANCE.getRobot_Bumper();

		/**
		 * The meta object literal for the '<em><b>Velocity</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ROBOT_BUMPER__VELOCITY = eINSTANCE.getRobot_Bumper_Velocity();

		/**
		 * The meta object literal for the '<em><b>Rotation</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ROBOT_BUMPER__ROTATION = eINSTANCE.getRobot_Bumper_Rotation();

		/**
		 * The meta object literal for the '<em><b>Robot Bumper</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ROBOT_BUMPER___ROBOT_BUMPER = eINSTANCE.getRobot_Bumper__Robot_Bumper();

		/**
		 * The meta object literal for the '<em><b>Init Behavior</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ROBOT_BUMPER___INIT_BEHAVIOR = eINSTANCE.getRobot_Bumper__InitBehavior();

		/**
		 * The meta object literal for the '<em><b>Bump</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ROBOT_BUMPER___BUMP = eINSTANCE.getRobot_Bumper__Bump();

		/**
		 * The meta object literal for the '<em><b>Perform Behavior</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ROBOT_BUMPER___PERFORM_BEHAVIOR = eINSTANCE.getRobot_Bumper__PerformBehavior();

		/**
		 * The meta object literal for the '{@link RootElement.ClassDiagrams.impl.Robot_CameraImpl <em>Robot Camera</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RootElement.ClassDiagrams.impl.Robot_CameraImpl
		 * @see RootElement.ClassDiagrams.impl.ClassDiagramsPackageImpl#getRobot_Camera()
		 * @generated
		 */
		EClass ROBOT_CAMERA = eINSTANCE.getRobot_Camera();

		/**
		 * The meta object literal for the '<em><b>Velocity</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ROBOT_CAMERA__VELOCITY = eINSTANCE.getRobot_Camera_Velocity();

		/**
		 * The meta object literal for the '<em><b>Rotation</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ROBOT_CAMERA__ROTATION = eINSTANCE.getRobot_Camera_Rotation();

		/**
		 * The meta object literal for the '<em><b>Camera</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ROBOT_CAMERA__CAMERA = eINSTANCE.getRobot_Camera_Camera();

		/**
		 * The meta object literal for the '<em><b>Init Behavior</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ROBOT_CAMERA___INIT_BEHAVIOR = eINSTANCE.getRobot_Camera__InitBehavior();

		/**
		 * The meta object literal for the '<em><b>Perform Behavior</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ROBOT_CAMERA___PERFORM_BEHAVIOR = eINSTANCE.getRobot_Camera__PerformBehavior();

		/**
		 * The meta object literal for the '<em><b>Robot Camera</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ROBOT_CAMERA___ROBOT_CAMERA = eINSTANCE.getRobot_Camera__Robot_Camera();

	}

} //ClassDiagramsPackage
