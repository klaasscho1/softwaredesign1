/**
 */
package RootElement.ClassDiagrams.impl;

import RootElement.ClassDiagrams.ClassDiagramsPackage;
import RootElement.ClassDiagrams.Robot_Camera;

import java.lang.reflect.InvocationTargetException;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EDataTypeUniqueEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Robot Camera</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link RootElement.ClassDiagrams.impl.Robot_CameraImpl#getVelocity <em>Velocity</em>}</li>
 *   <li>{@link RootElement.ClassDiagrams.impl.Robot_CameraImpl#getRotation <em>Rotation</em>}</li>
 *   <li>{@link RootElement.ClassDiagrams.impl.Robot_CameraImpl#getCamera <em>Camera</em>}</li>
 * </ul>
 *
 * @generated
 */
public class Robot_CameraImpl extends MinimalEObjectImpl.Container implements Robot_Camera {
	/**
	 * The default value of the '{@link #getVelocity() <em>Velocity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVelocity()
	 * @generated
	 * @ordered
	 */
	protected static final double VELOCITY_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getVelocity() <em>Velocity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVelocity()
	 * @generated
	 * @ordered
	 */
	protected double velocity = VELOCITY_EDEFAULT;

	/**
	 * The default value of the '{@link #getRotation() <em>Rotation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRotation()
	 * @generated
	 * @ordered
	 */
	protected static final double ROTATION_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getRotation() <em>Rotation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRotation()
	 * @generated
	 * @ordered
	 */
	protected double rotation = ROTATION_EDEFAULT;

	/**
	 * The cached value of the '{@link #getCamera() <em>Camera</em>}' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCamera()
	 * @generated
	 * @ordered
	 */
	protected EList<Object> camera;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Robot_CameraImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ClassDiagramsPackage.Literals.ROBOT_CAMERA;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public double getVelocity() {
		return velocity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setVelocity(double newVelocity) {
		double oldVelocity = velocity;
		velocity = newVelocity;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ClassDiagramsPackage.ROBOT_CAMERA__VELOCITY, oldVelocity, velocity));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public double getRotation() {
		return rotation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setRotation(double newRotation) {
		double oldRotation = rotation;
		rotation = newRotation;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ClassDiagramsPackage.ROBOT_CAMERA__ROTATION, oldRotation, rotation));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Object> getCamera() {
		if (camera == null) {
			camera = new EDataTypeUniqueEList<Object>(Object.class, this, ClassDiagramsPackage.ROBOT_CAMERA__CAMERA);
		}
		return camera;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initBehavior() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void performBehavior() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void Robot_Camera() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case ClassDiagramsPackage.ROBOT_CAMERA__VELOCITY:
				return getVelocity();
			case ClassDiagramsPackage.ROBOT_CAMERA__ROTATION:
				return getRotation();
			case ClassDiagramsPackage.ROBOT_CAMERA__CAMERA:
				return getCamera();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case ClassDiagramsPackage.ROBOT_CAMERA__VELOCITY:
				setVelocity((Double)newValue);
				return;
			case ClassDiagramsPackage.ROBOT_CAMERA__ROTATION:
				setRotation((Double)newValue);
				return;
			case ClassDiagramsPackage.ROBOT_CAMERA__CAMERA:
				getCamera().clear();
				getCamera().addAll((Collection<? extends Object>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case ClassDiagramsPackage.ROBOT_CAMERA__VELOCITY:
				setVelocity(VELOCITY_EDEFAULT);
				return;
			case ClassDiagramsPackage.ROBOT_CAMERA__ROTATION:
				setRotation(ROTATION_EDEFAULT);
				return;
			case ClassDiagramsPackage.ROBOT_CAMERA__CAMERA:
				getCamera().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case ClassDiagramsPackage.ROBOT_CAMERA__VELOCITY:
				return velocity != VELOCITY_EDEFAULT;
			case ClassDiagramsPackage.ROBOT_CAMERA__ROTATION:
				return rotation != ROTATION_EDEFAULT;
			case ClassDiagramsPackage.ROBOT_CAMERA__CAMERA:
				return camera != null && !camera.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
			case ClassDiagramsPackage.ROBOT_CAMERA___INIT_BEHAVIOR:
				initBehavior();
				return null;
			case ClassDiagramsPackage.ROBOT_CAMERA___PERFORM_BEHAVIOR:
				performBehavior();
				return null;
			case ClassDiagramsPackage.ROBOT_CAMERA___ROBOT_CAMERA:
				Robot_Camera();
				return null;
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (velocity: ");
		result.append(velocity);
		result.append(", rotation: ");
		result.append(rotation);
		result.append(", camera: ");
		result.append(camera);
		result.append(')');
		return result.toString();
	}

} //Robot_CameraImpl
