/**
 */
package RootElement.ClassDiagrams.impl;

import RootElement.ClassDiagrams.ClassDiagramsPackage;
import RootElement.ClassDiagrams.Robot_Picker;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Robot Picker</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link RootElement.ClassDiagrams.impl.Robot_PickerImpl#getVelocity <em>Velocity</em>}</li>
 *   <li>{@link RootElement.ClassDiagrams.impl.Robot_PickerImpl#getNoOfCherries <em>No Of Cherries</em>}</li>
 * </ul>
 *
 * @generated
 */
public class Robot_PickerImpl extends MinimalEObjectImpl.Container implements Robot_Picker {
	/**
	 * The default value of the '{@link #getVelocity() <em>Velocity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVelocity()
	 * @generated
	 * @ordered
	 */
	protected static final double VELOCITY_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getVelocity() <em>Velocity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVelocity()
	 * @generated
	 * @ordered
	 */
	protected double velocity = VELOCITY_EDEFAULT;

	/**
	 * The default value of the '{@link #getNoOfCherries() <em>No Of Cherries</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNoOfCherries()
	 * @generated
	 * @ordered
	 */
	protected static final int NO_OF_CHERRIES_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getNoOfCherries() <em>No Of Cherries</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNoOfCherries()
	 * @generated
	 * @ordered
	 */
	protected int noOfCherries = NO_OF_CHERRIES_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Robot_PickerImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ClassDiagramsPackage.Literals.ROBOT_PICKER;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public double getVelocity() {
		return velocity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setVelocity(double newVelocity) {
		double oldVelocity = velocity;
		velocity = newVelocity;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ClassDiagramsPackage.ROBOT_PICKER__VELOCITY, oldVelocity, velocity));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getNoOfCherries() {
		return noOfCherries;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNoOfCherries(int newNoOfCherries) {
		int oldNoOfCherries = noOfCherries;
		noOfCherries = newNoOfCherries;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ClassDiagramsPackage.ROBOT_PICKER__NO_OF_CHERRIES, oldNoOfCherries, noOfCherries));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case ClassDiagramsPackage.ROBOT_PICKER__VELOCITY:
				return getVelocity();
			case ClassDiagramsPackage.ROBOT_PICKER__NO_OF_CHERRIES:
				return getNoOfCherries();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case ClassDiagramsPackage.ROBOT_PICKER__VELOCITY:
				setVelocity((Double)newValue);
				return;
			case ClassDiagramsPackage.ROBOT_PICKER__NO_OF_CHERRIES:
				setNoOfCherries((Integer)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case ClassDiagramsPackage.ROBOT_PICKER__VELOCITY:
				setVelocity(VELOCITY_EDEFAULT);
				return;
			case ClassDiagramsPackage.ROBOT_PICKER__NO_OF_CHERRIES:
				setNoOfCherries(NO_OF_CHERRIES_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case ClassDiagramsPackage.ROBOT_PICKER__VELOCITY:
				return velocity != VELOCITY_EDEFAULT;
			case ClassDiagramsPackage.ROBOT_PICKER__NO_OF_CHERRIES:
				return noOfCherries != NO_OF_CHERRIES_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (velocity: ");
		result.append(velocity);
		result.append(", noOfCherries: ");
		result.append(noOfCherries);
		result.append(')');
		return result.toString();
	}

} //Robot_PickerImpl
