/**
 */
package RootElement.ClassDiagrams.impl;

import RootElement.ClassDiagrams.ClassDiagramsPackage;
import RootElement.ClassDiagrams.Environment;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.TreeIterator;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EStructuralFeature;

import java.awt.Color;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;
import org.eclipse.emf.ecore.resource.Resource;

import java.awt.Color;
import javax.vecmath.Color3f;
import javax.vecmath.Vector3d;
import javax.vecmath.Vector3f;
import simbad.sim.*;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Environment</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class EnvironmentImpl extends MinimalEObjectImpl.Container implements Environment  {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EnvironmentImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */

	
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ClassDiagramsPackage.Literals.ENVIRONMENT;
	}


	public void Environment() {
		// turn on the lights
        this.light1IsOn = true;
        this.light2IsOn = true;
        
        // show the axes so that we know where things are
        this.showAxis(true);
        
        // Set the world size
        this.setWorldSize(25);
        
        //Creating the Walls 
        
        Wall topWall = new Wall(new Vector3d(-12.5,0, 0), 25, 2, this);
        topWall.setColor(new Color3f(Color.GREEN));
        topWall.rotate90(1);
        add(topWall);
        
        Wall bottomWall = new Wall(new Vector3d(12.5, 0, 0), 25, 2, this);
        bottomWall.setColor(new Color3f(Color.BLUE));
        bottomWall.rotate90(1);
        add(bottomWall);
        
        Wall leftWall = new Wall(new Vector3d(0, 0, 12.5), 25, 2, this);
        leftWall.setColor(new Color3f(Color.BLACK));
        add(leftWall);
        
        Wall rigthWall = new Wall(new Vector3d(0, 0, -12.5), 25, 2, this);
        rigthWall.setColor(new Color3f(Color.YELLOW));
        add(rigthWall);
        
        Box b1 = new Box(new Vector3d(-3, 0 , 3), new Vector3f(1, 1, 1), this);
        b1.setColor(new Color3f(Color.BLACK));
        add(b1);
        
        Box b2 = new Box(new Vector3d(6, 0 , -6), new Vector3f(1, 1, 1), this);
        b2.setColor(new Color3f(Color.BLACK));
        add(b2);
        
        
      
        Arch a1 = new Arch(new Vector3d(3, 0, -3), this);
        a1.rotate90(1);
        add(a1);
        
        Wall interiorOne = new Wall(new Vector3d(-4, 0, -4), 4, 2, this);
        interiorOne.setColor(new Color3f(Color.BLUE));
        add(interiorOne);
        
        Wall interiorSecond = new Wall(new Vector3d(-5,0,-3),2,2,this);
        interiorSecond.rotate90(1);
        interiorSecond.setColor(blue);
        add(interiorSecond);
        
        
        light1IsOn = true;
        light2IsOn = true;
        
        light1SetPosition(6,.7f,5);
        light2SetPosition(9,.7f,2);
        
        light1Color = white;
        light2Color = white;
        
        
        // Add cherries in random places throughout the world
       
        for( int n =0; n < 1;n++){
            double x =( Math.random()*10 - 5);
            double z = (Math.random()*10 - 5);
            add(new CherryAgent(new Vector3d(x, 0, z), "cherry", 0.15f));
        }
        
	 
	}
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
			case ClassDiagramsPackage.ENVIRONMENT___ENVIRONMENT:
				Environment();
				return null;
		}
		return super.eInvoke(operationID, arguments);
	}
	@Override
	public EClass eClass() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public Resource eResource() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public EObject eContainer() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public EStructuralFeature eContainingFeature() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public EReference eContainmentFeature() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public EList<EObject> eContents() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public TreeIterator<EObject> eAllContents() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public boolean eIsProxy() {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public EList<EObject> eCrossReferences() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public Object eGet(EStructuralFeature feature) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public Object eGet(EStructuralFeature feature, boolean resolve) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public void eSet(EStructuralFeature feature, Object newValue) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public boolean eIsSet(EStructuralFeature feature) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public void eUnset(EStructuralFeature feature) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public Object eInvoke(EOperation operation, EList<?> arguments) throws InvocationTargetException {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public EList<Adapter> eAdapters() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public boolean eDeliver() {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public void eSetDeliver(boolean deliver) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void eNotify(Notification notification) {
		// TODO Auto-generated method stub
		
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	
	
} //EnvironmentImpl
