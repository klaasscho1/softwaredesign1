/**
 */
package RootElement.ClassDiagrams.impl;

import javax.vecmath.Vector3d;
import simbad.gui.Simbad;
import simbad.sim.EnvironmentDescription;
import RootElement.ClassDiagrams.ClassDiagramsPackage;
import RootElement.ClassDiagrams.Main;
import main.java.softdesign.Environment;
import main.java.softdesign.Robot_bumper;
import main.java.softdesign.Robot_cam;
import main.java.softdesign.Robot_picker;
import simbad.gui.Simbad;
import simbad.sim.EnvironmentDescription;

import java.lang.reflect.InvocationTargetException;

import javax.vecmath.Vector3d;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Main</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class MainImpl extends MinimalEObjectImpl.Container implements Main {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MainImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ClassDiagramsPackage.Literals.MAIN;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void Main() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
public static void main(String[] args) {
		
		System.setProperty("j3d.implicitAntialiasing", "true");
		
		EnvironmentDescription environment = new Environment();
	
		Robot_cam camera = new Robot_cam(new Vector3d(2,0,3), "camera");
		Robot_bumper bumper = new Robot_bumper(new Vector3d(0,0,6), "robot_bumper");
		Robot_picker picker = new Robot_picker(new Vector3d(10,0,10), "robot_picker");
		
		
		environment.add(camera);
		environment.add(bumper);
		environment.add(picker);
		
		Simbad frame = new Simbad(environment, false);
      	frame.update(frame.getGraphics()); 
			
	}
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
			case ClassDiagramsPackage.MAIN___MAIN:
				Main();
				return null;
		}
		return super.eInvoke(operationID, arguments);
	}

} //MainImpl
