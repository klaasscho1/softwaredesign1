/**
 */
package RootElement.ClassDiagrams.impl;

import RootElement.ClassDiagrams.ClassDiagramsFactory;
import RootElement.ClassDiagrams.ClassDiagramsPackage;
import RootElement.ClassDiagrams.Environment;
import RootElement.ClassDiagrams.Main;
import RootElement.ClassDiagrams.Robot;
import RootElement.ClassDiagrams.Robot_Bumper;
import RootElement.ClassDiagrams.Robot_Camera;
import RootElement.ClassDiagrams.Robot_Picker;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class ClassDiagramsPackageImpl extends EPackageImpl implements ClassDiagramsPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass environmentEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass mainEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass robot_PickerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass robotEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass robot_BumperEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass robot_CameraEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see RootElement.ClassDiagrams.ClassDiagramsPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private ClassDiagramsPackageImpl() {
		super(eNS_URI, ClassDiagramsFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 * 
	 * <p>This method is used to initialize {@link ClassDiagramsPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static ClassDiagramsPackage init() {
		if (isInited) return (ClassDiagramsPackage)EPackage.Registry.INSTANCE.getEPackage(ClassDiagramsPackage.eNS_URI);

		// Obtain or create and register package
		ClassDiagramsPackageImpl theClassDiagramsPackage = (ClassDiagramsPackageImpl)(EPackage.Registry.INSTANCE.get(eNS_URI) instanceof ClassDiagramsPackageImpl ? EPackage.Registry.INSTANCE.get(eNS_URI) : new ClassDiagramsPackageImpl());

		isInited = true;

		// Create package meta-data objects
		theClassDiagramsPackage.createPackageContents();

		// Initialize created meta-data
		theClassDiagramsPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theClassDiagramsPackage.freeze();

  
		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(ClassDiagramsPackage.eNS_URI, theClassDiagramsPackage);
		return theClassDiagramsPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getEnvironment() {
		return environmentEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getEnvironment__Environment() {
		return environmentEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getMain() {
		return mainEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getMain__Main() {
		return mainEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getRobot_Picker() {
		return robot_PickerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRobot_Picker_Velocity() {
		return (EAttribute)robot_PickerEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRobot_Picker_NoOfCherries() {
		return (EAttribute)robot_PickerEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getRobot() {
		return robotEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRobot_Velocity() {
		return (EAttribute)robotEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRobot_Rotation() {
		return (EAttribute)robotEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRobot_ToreTime() {
		return (EAttribute)robotEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getRobot__Robot() {
		return robotEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getRobot__InitBehavior() {
		return robotEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getRobot__PerformBehavior() {
		return robotEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getRobot_Bumper() {
		return robot_BumperEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRobot_Bumper_Velocity() {
		return (EAttribute)robot_BumperEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRobot_Bumper_Rotation() {
		return (EAttribute)robot_BumperEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getRobot_Bumper__Robot_Bumper() {
		return robot_BumperEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getRobot_Bumper__InitBehavior() {
		return robot_BumperEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getRobot_Bumper__Bump() {
		return robot_BumperEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getRobot_Bumper__PerformBehavior() {
		return robot_BumperEClass.getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getRobot_Camera() {
		return robot_CameraEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRobot_Camera_Velocity() {
		return (EAttribute)robot_CameraEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRobot_Camera_Rotation() {
		return (EAttribute)robot_CameraEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRobot_Camera_Camera() {
		return (EAttribute)robot_CameraEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getRobot_Camera__InitBehavior() {
		return robot_CameraEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getRobot_Camera__PerformBehavior() {
		return robot_CameraEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getRobot_Camera__Robot_Camera() {
		return robot_CameraEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ClassDiagramsFactory getClassDiagramsFactory() {
		return (ClassDiagramsFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		environmentEClass = createEClass(ENVIRONMENT);
		createEOperation(environmentEClass, ENVIRONMENT___ENVIRONMENT);

		mainEClass = createEClass(MAIN);
		createEOperation(mainEClass, MAIN___MAIN);

		robot_PickerEClass = createEClass(ROBOT_PICKER);
		createEAttribute(robot_PickerEClass, ROBOT_PICKER__VELOCITY);
		createEAttribute(robot_PickerEClass, ROBOT_PICKER__NO_OF_CHERRIES);

		robotEClass = createEClass(ROBOT);
		createEAttribute(robotEClass, ROBOT__VELOCITY);
		createEAttribute(robotEClass, ROBOT__ROTATION);
		createEAttribute(robotEClass, ROBOT__TORE_TIME);
		createEOperation(robotEClass, ROBOT___ROBOT);
		createEOperation(robotEClass, ROBOT___INIT_BEHAVIOR);
		createEOperation(robotEClass, ROBOT___PERFORM_BEHAVIOR);

		robot_BumperEClass = createEClass(ROBOT_BUMPER);
		createEAttribute(robot_BumperEClass, ROBOT_BUMPER__VELOCITY);
		createEAttribute(robot_BumperEClass, ROBOT_BUMPER__ROTATION);
		createEOperation(robot_BumperEClass, ROBOT_BUMPER___ROBOT_BUMPER);
		createEOperation(robot_BumperEClass, ROBOT_BUMPER___INIT_BEHAVIOR);
		createEOperation(robot_BumperEClass, ROBOT_BUMPER___BUMP);
		createEOperation(robot_BumperEClass, ROBOT_BUMPER___PERFORM_BEHAVIOR);

		robot_CameraEClass = createEClass(ROBOT_CAMERA);
		createEAttribute(robot_CameraEClass, ROBOT_CAMERA__VELOCITY);
		createEAttribute(robot_CameraEClass, ROBOT_CAMERA__ROTATION);
		createEAttribute(robot_CameraEClass, ROBOT_CAMERA__CAMERA);
		createEOperation(robot_CameraEClass, ROBOT_CAMERA___INIT_BEHAVIOR);
		createEOperation(robot_CameraEClass, ROBOT_CAMERA___PERFORM_BEHAVIOR);
		createEOperation(robot_CameraEClass, ROBOT_CAMERA___ROBOT_CAMERA);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes

		// Initialize classes, features, and operations; add parameters
		initEClass(environmentEClass, Environment.class, "Environment", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEOperation(getEnvironment__Environment(), null, "Environment", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(mainEClass, Main.class, "Main", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEOperation(getMain__Main(), null, "Main", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(robot_PickerEClass, Robot_Picker.class, "Robot_Picker", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getRobot_Picker_Velocity(), ecorePackage.getEDouble(), "velocity", null, 1, 1, Robot_Picker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getRobot_Picker_NoOfCherries(), ecorePackage.getEInt(), "noOfCherries", null, 1, 1, Robot_Picker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEClass(robotEClass, Robot.class, "Robot", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getRobot_Velocity(), ecorePackage.getEDouble(), "velocity", null, 1, 1, Robot.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getRobot_Rotation(), ecorePackage.getEDouble(), "rotation", null, 1, 1, Robot.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getRobot_ToreTime(), ecorePackage.getEDouble(), "toreTime", null, 1, 1, Robot.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEOperation(getRobot__Robot(), null, "Robot", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getRobot__InitBehavior(), null, "initBehavior", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getRobot__PerformBehavior(), null, "performBehavior", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(robot_BumperEClass, Robot_Bumper.class, "Robot_Bumper", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getRobot_Bumper_Velocity(), ecorePackage.getEDouble(), "velocity", null, 1, 1, Robot_Bumper.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getRobot_Bumper_Rotation(), ecorePackage.getEDouble(), "rotation", null, 1, 1, Robot_Bumper.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEOperation(getRobot_Bumper__Robot_Bumper(), null, "Robot_Bumper", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getRobot_Bumper__InitBehavior(), null, "initBehavior", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getRobot_Bumper__Bump(), null, "bump", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getRobot_Bumper__PerformBehavior(), null, "performBehavior", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(robot_CameraEClass, Robot_Camera.class, "Robot_Camera", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getRobot_Camera_Velocity(), ecorePackage.getEDouble(), "velocity", null, 1, 1, Robot_Camera.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getRobot_Camera_Rotation(), ecorePackage.getEDouble(), "rotation", null, 1, 1, Robot_Camera.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getRobot_Camera_Camera(), ecorePackage.getEJavaObject(), "camera", null, 1, -1, Robot_Camera.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEOperation(getRobot_Camera__InitBehavior(), null, "initBehavior", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getRobot_Camera__PerformBehavior(), null, "performBehavior", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getRobot_Camera__Robot_Camera(), null, "Robot_Camera", 1, 1, IS_UNIQUE, !IS_ORDERED);

		// Create resource
		createResource(eNS_URI);
	}

} //ClassDiagramsPackageImpl
