/**
 */
package RootElement.ClassDiagrams.impl;

import RootElement.ClassDiagrams.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class ClassDiagramsFactoryImpl extends EFactoryImpl implements ClassDiagramsFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static ClassDiagramsFactory init() {
		try {
			ClassDiagramsFactory theClassDiagramsFactory = (ClassDiagramsFactory)EPackage.Registry.INSTANCE.getEFactory(ClassDiagramsPackage.eNS_URI);
			if (theClassDiagramsFactory != null) {
				return theClassDiagramsFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new ClassDiagramsFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ClassDiagramsFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case ClassDiagramsPackage.ENVIRONMENT: return createEnvironment();
			case ClassDiagramsPackage.MAIN: return createMain();
			case ClassDiagramsPackage.ROBOT_PICKER: return createRobot_Picker();
			case ClassDiagramsPackage.ROBOT: return createRobot();
			case ClassDiagramsPackage.ROBOT_BUMPER: return createRobot_Bumper();
			case ClassDiagramsPackage.ROBOT_CAMERA: return createRobot_Camera();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Environment createEnvironment() {
		EnvironmentImpl environment = new EnvironmentImpl();
		return environment;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Main createMain() {
		MainImpl main = new MainImpl();
		return main;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Robot_Picker createRobot_Picker() {
		Robot_PickerImpl robot_Picker = new Robot_PickerImpl();
		return robot_Picker;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Robot createRobot() {
		RobotImpl robot = new RobotImpl();
		return robot;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Robot_Bumper createRobot_Bumper() {
		Robot_BumperImpl robot_Bumper = new Robot_BumperImpl();
		return robot_Bumper;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Robot_Camera createRobot_Camera() {
		Robot_CameraImpl robot_Camera = new Robot_CameraImpl();
		return robot_Camera;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ClassDiagramsPackage getClassDiagramsPackage() {
		return (ClassDiagramsPackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static ClassDiagramsPackage getPackage() {
		return ClassDiagramsPackage.eINSTANCE;
	}

} //ClassDiagramsFactoryImpl
