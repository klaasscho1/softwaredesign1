/**
 */
package RootElement.ClassDiagrams;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Robot Bumper</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link RootElement.ClassDiagrams.Robot_Bumper#getVelocity <em>Velocity</em>}</li>
 *   <li>{@link RootElement.ClassDiagrams.Robot_Bumper#getRotation <em>Rotation</em>}</li>
 * </ul>
 *
 * @see RootElement.ClassDiagrams.ClassDiagramsPackage#getRobot_Bumper()
 * @model
 * @generated
 */
public interface Robot_Bumper extends EObject {
	/**
	 * Returns the value of the '<em><b>Velocity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Velocity</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Velocity</em>' attribute.
	 * @see #setVelocity(double)
	 * @see RootElement.ClassDiagrams.ClassDiagramsPackage#getRobot_Bumper_Velocity()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	double getVelocity();

	/**
	 * Sets the value of the '{@link RootElement.ClassDiagrams.Robot_Bumper#getVelocity <em>Velocity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Velocity</em>' attribute.
	 * @see #getVelocity()
	 * @generated
	 */
	void setVelocity(double value);

	/**
	 * Returns the value of the '<em><b>Rotation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Rotation</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Rotation</em>' attribute.
	 * @see #setRotation(double)
	 * @see RootElement.ClassDiagrams.ClassDiagramsPackage#getRobot_Bumper_Rotation()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	double getRotation();

	/**
	 * Sets the value of the '{@link RootElement.ClassDiagrams.Robot_Bumper#getRotation <em>Rotation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Rotation</em>' attribute.
	 * @see #getRotation()
	 * @generated
	 */
	void setRotation(double value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void Robot_Bumper();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void initBehavior();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void bump();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void performBehavior();

} // Robot_Bumper
